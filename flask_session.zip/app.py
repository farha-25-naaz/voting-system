import os
import random
from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_pymongo import PyMongo
from flask_session import Session
from twilio.rest import Client
from dotenv import load_dotenv

# ✅ Load environment variables from .env file
load_dotenv()

app = Flask(__name__)

# ✅ MongoDB Configuration
MONGO_URI = os.getenv("MONGO_URI")
if not MONGO_URI:
    raise ValueError("MONGO_URI is not set. Please check your .env file.")

app.config["MONGO_URI"] = MONGO_URI
mongo = PyMongo(app)

# ✅ Session Configuration (Fix missing secret key)
app.secret_key = os.getenv("SECRET_KEY", "default_secret_key")
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_PERMANENT"] = False  # Ensures session data clears after closing browser
Session(app)

# ✅ Twilio Configuration
TWILIO_SID = os.getenv("TWILIO_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_WHATSAPP_NUMBER = "whatsapp:+14155238886"

if not TWILIO_SID or not TWILIO_AUTH_TOKEN:
    raise ValueError("Twilio credentials are missing. Check your .env file.")

client = Client(TWILIO_SID, TWILIO_AUTH_TOKEN)

# ✅ Home/Login Page
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        session["name"] = request.form["name"]
        session["email"] = request.form["email"]
        session["mobile"] = request.form["mobile"]

        # ✅ Generate OTP and store in session
        otp = str(random.randint(1000, 9999))
        session["otp"] = otp

        try:
            client.messages.create(
                body=f"Your OTP for the voting system is {otp}",
                from_=TWILIO_WHATSAPP_NUMBER,
                to=f"whatsapp:+91{session['mobile']}"
            )
            flash("OTP sent successfully via WhatsApp.", "success")
        except Exception as e:
            flash(f"Error sending OTP: {e}", "danger")
            return redirect(url_for("login"))

        return redirect(url_for("otp_verification"))

    return render_template("login.html")

# ✅ OTP Verification Page
@app.route("/otp", methods=["GET", "POST"])
def otp_verification():
    if request.method == "POST":
        entered_otp = request.form["otp"]
        if entered_otp == session.get("otp"):
            session["otp"] = None  # ✅ Prevent reuse of OTP
            return redirect(url_for("vote"))
        else:
            flash("Invalid OTP. Try again.", "danger")
            return redirect(url_for("otp_verification"))

    return render_template("otp.html")

# ✅ Voting Page
@app.route("/vote", methods=["GET", "POST"])
def vote():
    if "mobile" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        party = request.form["party"]
        mobile = session["mobile"]

        # ✅ Check if user has already voted
        if mongo.db.votes.find_one({"mobile": mobile}):
            flash("You have already voted!", "warning")
            return redirect(url_for("result"))

        # ✅ Store vote in MongoDB
        mongo.db.votes.insert_one({"name": session["name"], "mobile": mobile, "party": party})
        flash("Vote cast successfully!", "success")
        return redirect(url_for("result"))

    return render_template("vote.html")

# ✅ Result Page (Vote Count)
@app.route("/result")
def result():
    vote_counts = mongo.db.votes.aggregate([
        {"$group": {"_id": "$party", "count": {"$sum": 1}}}
    ])
    
    # ✅ Ensures proper dictionary format and prevents errors when no votes exist
    results = {vote["_id"]: vote["count"] for vote in vote_counts} if vote_counts else {}

    return render_template("result.html", results=results)

if __name__ == "__main__":
    app.run(debug=True)
